package utilities;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import testBase.BaseTest;

public class TestListener implements ITestListener {
    private static ExtentReports extent = ExtentManager.getInstance();
    private static ThreadLocal<ExtentTest> testReport = new ThreadLocal<>();
    private static List<TestResultData> pdfResults = new ArrayList<>();
    
    private static String timeStamp;
    private static String extentReportPath;
    private static String pdfReportPath;
    
    @Override
    public void onStart(ITestContext context) {
        // generate single timestamp per suite execution
        timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());

        // report paths
        extentReportPath = System.getProperty("user.dir") + "/reports/ExtentReport_" + timeStamp + ".html";
        pdfReportPath = System.getProperty("user.dir") + "/reports/TestReport_" + timeStamp + ".pdf";

        System.out.println("Reports will be generated at: ");
        System.out.println("Extent HTML: " + extentReportPath);
        System.out.println("PDF Report : " + pdfReportPath);
    }
    
    @Override
    public void onTestStart(ITestResult result) {
        ExtentTest test = extent.createTest(result.getMethod().getMethodName());
        testReport.set(test);
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        testReport.get().log(Status.PASS, "Test passed");

        Object testClass = result.getInstance();
        WebDriver driver = ((BaseTest) testClass).getDriver();

        // capture screenshot
        String path = ScreenshotUtil.capture(driver, result.getMethod().getMethodName());
        String executionTime = new java.util.Date().toString();

        if (path != null) {
            try {
                testReport.get().addScreenCaptureFromPath(path);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        pdfResults.add(new TestResultData(
                result.getMethod().getMethodName(),
                "PASS",
                null,          // no exception
                path,          // screenshot path
                executionTime  // execution timestamp
        ));
    }



    @Override
    public void onTestFailure(ITestResult result) {
    	testReport.get().log(Status.FAIL, "Test failed: " + result.getThrowable());

        Object testClass = result.getInstance();
        WebDriver driver = ((BaseTest) testClass).getDriver();

        String path = ScreenshotUtil.capture(driver, result.getMethod().getMethodName());
        String executionTime = new java.util.Date().toString();

        if (path != null) {
            try {
                testReport.get().addScreenCaptureFromPath(path);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        pdfResults.add(new TestResultData(
                result.getMethod().getMethodName(),
                "FAIL",
                result.getThrowable().toString(),
                path,
                executionTime
        ));
    }
    
    @Override
    public void onTestSkipped(ITestResult result) {
        testReport.get().log(Status.SKIP, "Test skipped: " + result.getThrowable());

        String executionTime = new Date().toString();
        pdfResults.add(new TestResultData(
                result.getMethod().getMethodName(),
                "SKIPPED",
                result.getThrowable() != null ? result.getThrowable().toString() : null,
                null,
                executionTime
        ));
    }

    @Override
    public void onFinish(ITestContext context) {
    	 // flush extent report
        extent.flush();

        // generate PDF report
        PdfReportUtil.generatePDF(pdfReportPath, pdfResults);

        System.out.println("===== Test Execution Finished =====");
        System.out.println("Extent HTML Report: " + extentReportPath);
        System.out.println("PDF Report         : " + pdfReportPath);
    }

}
