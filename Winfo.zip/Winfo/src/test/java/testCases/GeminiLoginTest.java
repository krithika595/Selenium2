package testCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pageObjects.FacebookLoginPage;
import pageObjects.GeminiLoginPage;

public class GeminiLoginTest {

    private WebDriver driver;
    private GeminiLoginPage loginPage;

    @BeforeClass
    public void setUp() {
        // Set your chromedriver path accordingly
       
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.facebook.com/");
        loginPage = new GeminiLoginPage(driver);
    }

    @Test
    public void loginTest() {
        loginPage.login("your_email@example.com", "your_password");

        // Add assertions here to verify login success
        // e.g. wait for homepage element or check URL
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}

