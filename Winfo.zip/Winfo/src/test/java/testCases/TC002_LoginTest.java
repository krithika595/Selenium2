package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import pageObjects.LoginPage;
import pageObjects.MyAccountPage;
import testBase.BaseTest;
import utilities.ConfigReader;

public class TC002_LoginTest extends BaseTest{
	@Test
	public void createLogin() {
		
		
		HomePage hp=new HomePage(driver);
		hp.clickMyAccount();
		hp.clickLogin();
		
		LoginPage lp=new LoginPage(driver);
		lp.setEmail(ConfigReader.get("email"));
		lp.setPassword(ConfigReader.get("password"));
		lp.clickSubmit();
		
		MyAccountPage myap=new MyAccountPage(driver);
		boolean status=myap.isMyAccountPageDisplayed();
		try {
			Assert.assertTrue(status);
		}catch(Exception e) {
			Assert.fail();
		}
	}

}
