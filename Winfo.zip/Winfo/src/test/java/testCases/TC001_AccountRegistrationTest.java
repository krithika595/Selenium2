package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import pageObjects.RegisterPage;
import testBase.BaseTest;
import utilities.ScreenshotUtil;

public class TC001_AccountRegistrationTest extends BaseTest{

	@Test
	public void createAccountTest() {
		log.info("***** TC001 started ****");
		
		
		HomePage hp=new HomePage(driver);
		
		hp.clickMyAccount();
		hp.clickRegister();
		
		RegisterPage rp=new RegisterPage(driver);
		rp.setFirstName(randomString().toUpperCase());
		rp.setLastName(randomString().toUpperCase());
		rp.setEmail(randomString()+"@gmail.com");
		rp.setTelephone(randomNumber());
		String pwd=randomAlphaNum();
		rp.setPassword(pwd);
		rp.setConfirmPwd(pwd);
		rp.clickAgree();
		rp.clickSubmit();
		
		String msg=rp.getConfirmMsg();
		try {
			Assert.assertEquals(msg, "Your Account Has Been Created!");
		}catch(Exception e) {
			Assert.fail();
		}
		ScreenshotUtil.capture(driver, "CreateAccountTest");
		log.info("***** TC001 ended****");
	}
}
