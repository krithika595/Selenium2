package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import pageObjects.LoginPage;
import pageObjects.MyAccountPage;
import testBase.BaseTest;
import utilities.ConfigReader;
import utilities.DataProviders;

public class TC003_LoginTest_DDT extends BaseTest{
	
	@Test(dataProvider="LoginData",dataProviderClass=DataProviders.class)
	public void createLogin(String username,String password,String exp) {
		
		
		HomePage hp=new HomePage(driver);
		hp.clickMyAccount();
		hp.clickLogin();
		
		LoginPage lp=new LoginPage(driver);
		lp.setEmail(username);
		lp.setPassword(password);
		lp.clickSubmit();
		
		MyAccountPage myap=new MyAccountPage(driver);
		
		try {
			boolean targetPage=myap.isMyAccountPageDisplayed();
			if(exp.equalsIgnoreCase("valid")) {
				if(targetPage==true) {
					Assert.assertTrue(true);
					myap.clickLogout();
				}else {
					Assert.assertTrue(false);
				}
			}else {
				if(targetPage==true) {
					Assert.assertTrue(false);
					myap.clickLogout();
				}else {
					Assert.assertTrue(true);
				}
			}
		}catch(Exception e) {
			
		}
	
			
			
		
	}
}
