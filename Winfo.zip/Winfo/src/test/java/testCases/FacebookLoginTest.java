package testCases;

import testBase.BaseTest;
import pageObjects.FacebookLoginPage;
import org.testng.annotations.Test;

public class FacebookLoginTest extends BaseTest {

    @Test
    public void loginTest() throws Exception {
        
        FacebookLoginPage loginPage = new FacebookLoginPage(driver);
        loginPage.login("testuser@example.com", "Password123");
    }
}
