package ai;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class CacheManager {
    private static final String CACHE_FILE = "locatorCache.ser";
    private static Map<String, String> cache = loadCache();

    @SuppressWarnings("unchecked")
    private static Map<String, String> loadCache() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(CACHE_FILE))) {
            return (Map<String, String>) ois.readObject();
        } catch (Exception e) {
            return new HashMap<>();
        }
    }

    public static void saveCache() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(CACHE_FILE))) {
            oos.writeObject(cache);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void put(String key, String value) {
        cache.put(key, value);
        saveCache();
    }

    public static String get(String key) {
        return cache.get(key);
    }
}
