package ai;

import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import utilities.ConfigReader;

public class GeminiHelper {

    private static final String API_KEY = ConfigReader.get("neha");
    private static final String ENDPOINT = "https://generativelanguage.googleapis.com/v1/models/gemini-1.5-pro-002:generateContent?key=" + API_KEY;
    
    public static String getLocator(String prompt) {
        try (CloseableHttpClient client = HttpClients.createDefault()) {
            HttpPost post = new HttpPost(ENDPOINT);

            JSONObject request = new JSONObject()
                .put("contents", new JSONArray()
                    .put(new JSONObject()
                        .put("parts", new JSONArray()
                            .put(new JSONObject()
                                .put("text", "Give me the XPath for: \"" + prompt + "\". Only return the XPath. No explanation.")))));

            post.setEntity(new StringEntity(request.toString()));
            post.setHeader("Content-Type", "application/json");

            String response = EntityUtils.toString(client.execute(post).getEntity());
            return parseLocatorFromResponse(response);

        } catch (Exception e) {
            throw new RuntimeException("Failed to get locator from Gemini API", e);
        }
    }

    private static String parseLocatorFromResponse(String json) {
        JSONObject obj = new JSONObject(json);

        if (!obj.has("candidates")) {
            throw new RuntimeException("Gemini response missing 'candidates' key. Raw response: " + json);
        }

        JSONArray candidates = obj.getJSONArray("candidates");
        JSONObject first = candidates.getJSONObject(0);
        String text = first.getJSONObject("content")
                           .getJSONArray("parts")
                           .getJSONObject(0)
                           .getString("text");

        return text.trim().replace("```", "").replace("xpath", "").trim();
    }

}
