package ai;

import com.theokanning.openai.OpenAiService;
import com.theokanning.openai.completion.chat.*;

import utilities.ConfigReader;

import java.time.Duration;
import java.util.Arrays;

public class OpenAiHelper {
    private static final String API_KEY = ConfigReader.get("api");
    String apikey=ConfigReader.get("api");
    public static String getLocator(String pageSource, String elementName) {
        // 1. Try cache first
        String cached = LocatorCache.getLocator(pageSource, elementName);
        if (cached != null) {
            return cached;
        }

        // 2. Call OpenAI with retry
        OpenAiService service = new OpenAiService(API_KEY, Duration.ofSeconds(60));

        ChatMessage systemMessage = new ChatMessage("system",
                "You are an assistant that extracts Selenium locators.");
        ChatMessage userMessage = new ChatMessage("user",
                "From this HTML, return JSON with {locatorType, locatorValue} " +
                "for element: " + elementName + "\n\n" + pageSource);

        ChatCompletionRequest request = ChatCompletionRequest.builder()
                .model("gpt-4o-mini")
                .messages(Arrays.asList(systemMessage, userMessage))
                .maxTokens(300)
                .build();

        String response = safeCreateCompletion(service, request);

        // 3. Save to cache
        LocatorCache.putLocator(pageSource, elementName, response);

        return response;
    }

    private static String safeCreateCompletion(OpenAiService service, ChatCompletionRequest request) {
        int retries = 3;
        int waitTime = 2000;

        for (int i = 0; i < retries; i++) {
            try {
                ChatCompletionResult result = service.createChatCompletion(request);
                return result.getChoices().get(0).getMessage().getContent();
            } catch (retrofit2.adapter.rxjava2.HttpException e) {
                if (e.code() == 429) {
                    System.out.println("Rate limit hit. Retrying in " + waitTime + "ms...");
                    try {
                        Thread.sleep(waitTime);
                    } catch (InterruptedException ignored) {}
                    waitTime *= 2;
                } else {
                    throw e;
                }
            }
        }
        throw new RuntimeException("Failed due to repeated rate limiting.");
    }
}
