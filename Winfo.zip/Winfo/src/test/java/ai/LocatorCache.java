package ai;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;

public class LocatorCache {
    private static final String CACHE_FILE = "locatorCache.json";
    private static Map<String, Map<String, String>> cache = new HashMap<>();

    static {
        loadCache();
    }

    private static void loadCache() {
        File file = new File(CACHE_FILE);
        if (file.exists()) {
            try {
                byte[] jsonData = Files.readAllBytes(file.toPath());
                ObjectMapper mapper = new ObjectMapper();
                cache = mapper.readValue(jsonData, Map.class);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static void saveCache() {
        try (FileWriter writer = new FileWriter(CACHE_FILE)) {
            ObjectMapper mapper = new ObjectMapper();
            mapper.writerWithDefaultPrettyPrinter().writeValue(writer, cache);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String getLocator(String page, String element) {
        return cache.containsKey(page) ? cache.get(page).get(element) : null;
    }

    public static void putLocator(String page, String element, String locatorJson) {
        cache.computeIfAbsent(page, k -> new HashMap<>()).put(element, locatorJson);
        saveCache();
    }
}
