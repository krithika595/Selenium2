package ai;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import ai.CacheManager;

public class AIElement {

    private static By getLocator(WebDriver driver, String description) throws Exception {
        String pageSource = driver.getPageSource();
        String cacheKey = description + "_" + pageSource.hashCode();

        String jsonResponse = CacheManager.get(cacheKey);
        if (jsonResponse == null) {
            jsonResponse = OpenAiHelper.getLocator(pageSource, description);
            CacheManager.put(cacheKey, jsonResponse);
        }

        return LocatorParser.parseLocator(jsonResponse);
    }

    public static WebElement find(WebDriver driver, String description) throws Exception {
        return driver.findElement(getLocator(driver, description));
    }

    public static void click(WebDriver driver, String description) throws Exception {
        find(driver, description).click();
    }

    public static void type(WebDriver driver, String description, String text) throws Exception {
        WebElement element = find(driver, description);
        element.clear();
        element.sendKeys(text);
    }
}
