package pageObjects;

import org.openqa.selenium.WebDriver;

import utilities.ElementUtil;

public class MyAccountPage {

	private WebDriver driver;
	private ElementUtil elementUtil;
	
	public MyAccountPage(WebDriver driver) {
		this.driver=driver;
		elementUtil=new ElementUtil(driver);
	}
	
	public boolean isMyAccountPageDisplayed() {
		return elementUtil.getElement("myAcc.displayText").isDisplayed();
	}
	
	public void clickLogout() {
		elementUtil.getElement("myAcc.logout").click();
	}
}
