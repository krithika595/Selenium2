package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import ai.GeminiHelper;

public class GeminiLoginPage {

    private WebDriver driver;

    // Locators fetched dynamically via GeminiHelper
    private By emailLocator;
    private By passwordLocator;
    private By loginButtonLocator;

    public GeminiLoginPage(WebDriver driver) {
        this.driver = driver;
        emailLocator = By.xpath(GeminiHelper.getLocator("Email input field on Facebook login page"));
        passwordLocator = By.xpath(GeminiHelper.getLocator("Password input field on Facebook login page"));
        loginButtonLocator = By.xpath(GeminiHelper.getLocator("Login button on Facebook login page"));
    }

    public void enterEmail(String email) {
        WebElement emailInput = driver.findElement(emailLocator);
        emailInput.clear();
        emailInput.sendKeys(email);
    }

    public void enterPassword(String password) {
        WebElement passwordInput = driver.findElement(passwordLocator);
        passwordInput.clear();
        passwordInput.sendKeys(password);
    }

    public void clickLogin() {
        driver.findElement(loginButtonLocator).click();
    }

    public void login(String email, String password) {
        enterEmail(email);
        enterPassword(password);
        clickLogin();
    }
}

