package pageObjects;

import ai.AIElement;
import org.openqa.selenium.WebDriver;

public class FacebookLoginPage {
    private WebDriver driver;

    public FacebookLoginPage(WebDriver driver) {
        this.driver = driver;
    }

    public void login(String username, String password) throws Exception {
        AIElement.type(driver, "Email address input facebook login", username);
        AIElement.type(driver, "Password input input facebook login", password);
        AIElement.click(driver, "Login button facebook");
    }
}
