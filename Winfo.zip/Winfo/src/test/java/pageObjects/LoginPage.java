package pageObjects;

import org.openqa.selenium.WebDriver;

import utilities.ElementUtil;

public class LoginPage {
	
	private WebDriver driver;
	private ElementUtil elementUtil;
	
	public LoginPage(WebDriver driver) {
		this.driver=driver;
		elementUtil=new ElementUtil(driver);
	}
	
	public void setEmail(String email) {
		elementUtil.getElement("login.email").sendKeys(email);
	}

	public void setPassword(String pwd) {
		elementUtil.getElement("login.password").sendKeys(pwd);
	}
	
	public void clickSubmit() {
		elementUtil.getElement("login.submit").click();
	}
}
