package pageObjects;

import org.openqa.selenium.WebDriver;

import utilities.ElementUtil;

public class HomePage {
	
	private WebDriver driver;
	private ElementUtil elementUtil;
	
	public HomePage(WebDriver driver){
		this.driver=driver;
		elementUtil=new ElementUtil(driver);
	}
	
	public void clickMyAccount() {
		elementUtil.getElement("oc.myaccount").click();	
	}
	
	public void clickRegister() {
		elementUtil.getElement("oc.register").click();
	}
	
	public void clickLogin() {
		elementUtil.getElement("oc.login").click();
	}

}
