package pageObjects;

import org.openqa.selenium.WebDriver;

import utilities.ElementUtil;

public class RegisterPage {
	
	private WebDriver driver;
	private ElementUtil elementUtil;
	
	public RegisterPage(WebDriver driver) {
		this.driver=driver;
		elementUtil=new ElementUtil(driver);
	}
	
	public void setFirstName(String fname) {
		elementUtil.getElement("oc.firstName").sendKeys(fname);
	}
	
	public void setLastName(String lname) {
		elementUtil.getElement("oc.lastName").sendKeys(lname);
	}
	
	public void setEmail(String email) {
		elementUtil.getElement("oc.email").sendKeys(email);
	}
	
	public void setTelephone(String phone) {
		elementUtil.getElement("oc.telephone").sendKeys(phone);
	}

	public void setPassword(String pass) {
		elementUtil.getElement("oc.password").sendKeys(pass);
	}
	
	public void setConfirmPwd(String pass) {
		elementUtil.getElement("oc.confirm").sendKeys(pass);
	}

	public void clickAgree() {
		elementUtil.getElement("oc.agree").click();
	}
	
	public void clickSubmit() {
		elementUtil.getElement("oc.submit").click();
	}
	
	public String getConfirmMsg() {
	
		return elementUtil.getElement("oc.accountCreatedMsg").getText();
		 
	}
}
